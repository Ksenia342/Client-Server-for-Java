USE Flights;

DROP TABLE Flights;

ALter table company_flight drop constraint company_flight_ibfk_2;

SHOW CREATE TABLE company_flight;

SHOW TABLES;

Use flights;

Create table Roles(
	id int auto_increment primary key,
    name varchar(10) not null
);

CREATE TABLE Users(
	id INT AUTO_INCREMENT PRIMARY KEY,
    login VARCHAR(50) NOT NULL,
    password VARCHAR(30) NOT NULL,
    role int NOT NULL,
    constraint fk_users_roles foreign key (role) references Roles(id) on delete cascade on update cascade
);

alter table Roles add column name varchar(10) not null;

create unique index uix_roles on Roles(name);

alter table users add constraint fk_users_roles foreign key (role) references Roles(id) on delete cascade on update cascade;

create unique index uix_users on Users(login);

CREATE TABLE Airports (
	id INT auto_increment not null primary key,
	iata VARCHAR(3) NOT NULL,
    city VARCHAR(30) NOT NULL,
    name VARCHAR(50) NOT NULL,
    temperature INT,
    weather VARCHAR(20),
    status tinyint NOT NULL,
    distance INT
);

create unique index uix_airports on Airports(iata);

alter table Airports add column status tinyint not null;

select * from Airports;

create table Planes (
	id INT auto_increment not null primary key,
    manufacturer VARCHAR(20) NOT NULL,
    iata VARCHAR(3) NOT NULL,
    icao VARCHAR(4) NOT NULL,
    max_weight INT,
    seats_amount INT NOT NULL,
	wingspan int,
    length int,
    status tinyint not null
);

create unique index uix_planes on Planes(icao);

create table Companies(
	id int auto_increment not null primary key,
    iata varchar(2) not null,
    icao varchar(3) not null,
    name varchar(30) not null,
    telephone_number varchar(20),
    email varchar(40),
    website varchar(50),
    terminal varchar(2) not null,
    service_company varchar(50)
);

create unique index uix_companies on Companies(iata);

alter table Counters drop constraint fk_counters_companies;

create table Counters(
	number tinyint unsigned not null primary key,
    terminal varchar(2) not null,
    status tinyint not null,
    company_iata varchar(2),
    constraint fk_counters_companies foreign key (company_iata) references Companies(iata) on delete cascade on update cascade
);

alter table Counters add constraint fk_counters_companies foreign key (company_iata) references Companies(iata) on delete cascade on update cascade;

alter table Counters add constraint fk_counters_companies foreign key (company_iata) references Companies(iata) on delete cascade on update cascade;

drop table Companies;

alter table Counters add column number tinyint unsigned not null primary key;

select * from counters;

show create table counters;

create table Staff(
	id int auto_increment not null primary key,
    company_iata varchar(2),
    last_name varchar(30) not null,
    first_name varchar(20) not null,
    father_name varchar(50),
    constraint fk_staff_companies foreign key (company_iata) references Companies(iata)
);

create table Personal_data(
	login varchar(50) not null,
    passport varchar(20) not null,
    last_name varchar(30) not null,
    first_name varchar(20) not null,
    father_name varchar(50),
    telephone_number varchar(20) not null,
    primary key(login, passport),
    constraint fk_personal_users foreign key (login) references Users(login) on delete cascade on update cascade
);

alter table Personal_data add constraint fk_personal_users foreign key (login) references Users(login) on delete cascade on update cascade;

show create table Personal_data;

create table Departures(
	id int auto_increment not null primary key,
    call_number int not null,
    company_iata varchar(2) not null,
    plane_icao varchar(4) not null,
    airport_iata varchar(3) not null,
    destination varchar(30) not null,
    status tinyint not null,
    arrival_time time(0) not null,
    date date not null,
    departure_time time(0) not null,
    calculated_time time(0),
    terminal varchar(2) not null,
    counter varchar(3),
    constraint fk_departures_companies foreign key (company_iata) references Companies(iata) on delete cascade on update cascade,
    constraint fk_departures_planes foreign key (plane_icao) references Planes(icao) on delete cascade on update cascade,
    constraint fk_departures_airports foreign key (airport_iata) references Airports(iata) on delete cascade on update cascade
);

create unique index uix_departures on Departures(call_number, company_iata);

create table Arrivals(
	id int auto_increment not null primary key,
    call_number int not null,
    company_iata varchar(2) not null,
    plane_icao varchar(4) not null,
    airport_iata varchar(3) not null,
    origin varchar(30) not null,
    status tinyint not null,
    departure_time time(0) not null,
    date date not null,
    arrival_time time(0) not null,
    calculated_time time(0),
    terminal varchar(2) not null,
    counter varchar(3),
    constraint fk_arrivals_companies foreign key (company_iata) references Companies(iata) on delete cascade on update cascade,
    constraint fk_arrivals_planes foreign key (plane_icao) references Planes(icao) on delete cascade on update cascade,
    constraint fk_arrivals_airports foreign key (airport_iata) references Airports(iata) on delete cascade on update cascade
);

create unique index uix_departures on Arrivals(call_number, company_iata);

create table Tickets(
	id int auto_increment not null primary key,
	login varchar(50) not null,
    passport varchar(20) not null,
    flight_id int not null,
    seat varchar(3) not null,
    constraint fk_tickets_personal foreign key (login, passport) references Personal_data(login, passport) on delete cascade on update cascade,
    constraint fk_tickets_flights foreign key (flight_id) references Departures(id) on delete cascade on update cascade
);

use Flights;

alter table Tickets add constraint fk_tickets_flights foreign key (flight_id) references Departures(id) on delete cascade on update cascade;

insert into Roles (id, name) values
(2, "User"),
(3, "Worker"),
(1, "Admin");

insert into Users(login, password, role) values
("ivanov", "password123", 1),
("petrov", "password456", 2),
("novikov", "password789", 3);

select * from users;

use flights;

delete from roles;